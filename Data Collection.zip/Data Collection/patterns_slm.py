# -*- coding: utf-8 -*-
"""
@copywrite, Ruizhe Lin and Peter Kner, University of Georgia, 2019
"""

import numpy as N
import struct
#import tifffile as tf

pi = N.pi

def test(Nx,Ny):
    ''' for the QXGA SLM, Nx=2048,Ny=1536 '''
    for m in range(5):
        a = patt_10pixel_ang00(Nx,Ny,m*2)
        fn = 'patt12_ang000_%d.bmp' % m
        writeBMP(fn,(a==1))
    for m in range(5):
        a = patt_10pixel_ang60(Nx,Ny,m*2,60) # check phase!
        fn = 'patt12_ang060_%d.bmp' % m
        writeBMP(fn,(a==1))
        a = N.fliplr(a)
        fn = 'patt6_ang120_%d.bmp' % m
        writeBMP(fn,(a==1))
    return True
    
def test_nonlinear(Nx,Ny):
    ''' for the QXGA SLM, Nx=2048,Ny=1536 '''
    for m in range(18):
        a = patt_36pixel_ang00(Nx,Ny,m)
        fn = 'patt36_ang000_phase%d.bmp' % m
        writeBMP(fn,(a==1))
    return True

# 5 pixel patterns /////////////////////////////////////////////////////////////
def patt_5pixel_ang00(Nx,Ny,phase):
    out = N.fromfunction(lambda i,j: (N.sign((i+phase)%5-2.5)),(Nx,Ny))
    return out

def patt_5pixel_ang60(Nx,Ny,phase,ang=60):
    p = -1*N.ones((Nx,Ny))
    if (ang==60):
        a1 = N.array([3,-4]) # for 60 deg., [3,4] for 120 deg.
        x = N.array(range(1,5)+range(2,6)+range(4,8)+range(6,10))
    elif (ang==120):
        a1 = N.array([3,4]) # for 60 deg., [3,4] for 120 deg.
        x = N.array(range(1,5)+range(2,6)+range(4,8)+range(6,10))
        x = x[::-1]
    else:
        raise "angle must be 60 or 120!"
    a2 = N.array([10,0])
    Nb = 16
    x += phase
    y = N.ones((4))
    y = N.append(y,y+1)
    y = N.append(y,y+2)
    for m in range(-200,200):
        for n in range(-200,200):
            for k in range(Nb):
                r = N.array([x[k],y[k]])+m*a1+n*a2
                if ((r[0]>=0) and (r[0]<Nx) and (r[1]>=0) and (r[1]<Ny)):
                    rx = int(r[0])
                    ry = int(r[1])
                    p[rx,ry] = 1
    return p

# 6 pixel patterns /////////////////////////////////////////////////////////////
def patt_6pixel_ang00(Nx,Ny,phase):
    out = N.fromfunction(lambda i,j: (N.sign((i+phase)%6-1.5)),(Nx,Ny))
    return out

def patt_6pixel_ang60(Nx,Ny,phase,ang=60):
    p = -1*N.ones((Nx,Ny))
    if (ang==60):
        a1 = N.array([7,4]) # for 60 deg., [3,4] for 120 deg.
        x = N.array(list(range(1,7))+list(range(3,9))+list(range(5,11))+list(range(7,13)))
    elif (ang==120):
        a1 = N.array([-7,4]) # for 60 deg., [3,4] for 120 deg.
        x = N.array(list(range(1,7))+list(range(3,9))+list(range(5,11))+list(range(7,13)))
        x = x[::-1]
    else:
        raise "angle must be 60 or 120!"
    a2 = N.array([12,0])
    Nb = int(24)
    x += phase
    y = N.ones((6))
    y = N.append(y,y+1)
    y = N.append(y,y+2)
    for m in range(-200,200):
        for n in range(-200,200):
            for k in range(Nb):
                xk = x[k]
                yk = y[k]
                r = N.array([xk,yk])+m*a1+n*a2
                if ((r[0]>=0) and (r[0]<Nx) and (r[1]>=0) and (r[1]<Ny)):
                    rx = int(r[0])
                    ry = int(r[1])
                    p[rx,ry] = 1
    return p
    
# 9 pixel patterns ////////////////////////////////////////////////////////////
def patt_9pixel_ang00(Nx,Ny,phase):
    out = N.fromfunction(lambda i,j: (N.sign((i+phase)%9-4.5)),(Nx,Ny))
    return out

def patt_9pixel_ang60(Nx,Ny,phase,ang=60):
    p = -1*N.ones((Nx,Ny))
    if (ang==60):
        a1 = N.array([7,4]) # for 60 deg., [3,4] for 120 deg.
        x = N.array(list(range(0,9))+list(range(2,11))+list(range(4,13))+list(range(6,15)))+1
    elif (ang==120):
        a1 = N.array([-7,4]) # for 60 deg., [3,4] for 120 deg.
        x = N.array(list(range(0,9))+list(range(2,11))+list(range(4,13))+list(range(6,15)))+1
        #x = N.array(range(1,7)+range(3,9)+range(5,11)+range(7,13))
        x = x[::-1]
    else:
        raise "angle must be 60 or 120!"
    a2 = N.array([18,0])
    Nb = int(36)
    Ntile = 400 # 200
    x += phase
    y = N.ones((9))
    y = N.append(y,y+1)
    y = N.append(y,y+2)
    for m in range(-Ntile,Ntile):
        for n in range(-Ntile,Ntile):
            for k in range(Nb):
                r = N.array([x[k],y[k]])+m*a1+n*a2
                if ((r[0]>=0) and (r[0]<Nx) and (r[1]>=0) and (r[1]<Ny)):
                    rx = int(r[0])
                    ry = int(r[1])
                    p[rx,ry] = 1
    return p

# 10 pixel patterns ////////////////////////////////////////////////////////////
def patt_10pixel_ang00(Nx,Ny,phase):
    out = N.fromfunction(lambda i,j: (N.sign((i+phase)%10-3.5)),(Nx,Ny))
    return out
  
def patt_10pixel_ang60(Nx,Ny,phase,ang=60):
    p = -1*N.ones((Nx,Ny))
    if ang: # 60 deg
        a1 = N.array([14,8]) # for 60 deg., [3,4] for 120 deg.
        x = N.array(list(range(0,9))+list(range(1,10))+list(range(3,12))+list(range(5,14))+list(range(7,16))+list(range(9,18))+list(range(11,20))+list(range(13,22)))+1
        a2 = N.array([20,0])
    else: # 120 deg
        a1 = N.array([-14,8]) # for 60 deg., [3,4] for 120 deg.
        x = N.array(list(range(0,12))+list(range(2,14))+list(range(4,16))+list(range(6,18))+list(range(8,20))+list(range(10,22))+list(range(12,24)))
        x = x[::-1]
        a2 = N.array([20,0])
    Nb = 40
    x += phase
    y = N.ones((10))
    y = N.append(y,y+1)
    y = N.append(y,y+2)
    y = N.append(y,y+4)
#    y = N.array([int(q/10) for q in range(8*14)])
    for m in range(-200,200):
        for n in range(-200,200):
            for k in range(Nb):
                xk = x[k]
                yk = y[k]
                r = N.array([xk,yk])+m*a1+n*a2
                if ((r[0]>=0) and (r[0]<Nx) and (r[1]>=0) and (r[1]<Ny)):
                    rx = int(r[0])
                    ry = int(r[1])
                    p[rx,ry] = 1
    return p
    
# 12 pixel patterns ////////////////////////////////////////////////////////////
def patt_12pixel_ang00(Nx,Ny,phase):
    out = N.fromfunction(lambda i,j: (N.sign((i+phase)%12-5.5)),(Nx,Ny))
    return out

def patt_12pixel_ang60(Nx,Ny,phase,ang=60):
    p = -1*N.ones((Nx,Ny))
    if ang: # 60 deg
        a1 = N.array([12,7]) # for 60 deg., [3,4] for 120 deg.
        x = N.array(list(range(0,12))+list(range(2,14))+list(range(4,16))+list(range(6,18))+list(range(8,20))+list(range(10,22))+list(range(12,24)))
        a2 = N.array([24,0])
    else: # 120 deg
        a1 = N.array([-12,7]) # for 60 deg., [3,4] for 120 deg.
        x = N.array(list(range(0,12))+list(range(2,14))+list(range(4,16))+list(range(6,18))+list(range(8,20))+list(range(10,22))+list(range(12,24)))
        x = x[::-1]
        a2 = N.array([24,0])
    Nb = len(x)
    x += phase
    y = N.array([int(q/12) for q in range(7*12)])
    for m in range(-150,150):
        for n in range(-150,150):
            for k in range(Nb):
                xk = x[k]
                yk = y[k]
                r = N.array([xk,yk])+m*a1+n*a2
                if ((r[0]>=0) and (r[0]<Nx) and (r[1]>=0) and (r[1]<Ny)):
                    rx = int(r[0])
                    ry = int(r[1])
                    p[rx,ry] = 1
    return p

# 36 pixel patterns ////////////////////////////////////////////////////////////
def patt_36pixel_ang00(Nx,Ny,phase):
    out = N.fromfunction(lambda i,j: (N.sign((i+phase)%36-17.5)),(Nx,Ny))
    return out

# writing to files /////////////////////////////////////////////////////////////
def writeBMP(filename,A):
    ''' writeBMP(filename,A) writes matrix A to filename as a bitmap file '''

    #A = double(A);
    #A = A';
    #A = fliplr(A);
    nx,ny = A.shape
    imsize = int(nx*ny/8)
    bfsize = int(nx*ny/8 + 62)

    fid = open(filename,'wb')

    # BITMAPFILEHEADER
    fid.write(struct.pack('h',19778)) # 2 bytes set to 'BM' for bitmap file
    fid.write(struct.pack('I',bfsize)) # 4 bytes specify size of file
    fid.write(struct.pack('h',0)) # bfReserved1 must be set to 0
    fid.write(struct.pack('h',0)) # bfReserved2 must be set to 0
    fid.write(struct.pack('i',62)) # bfOffBits, 4 bytes specify offset from beginning of file to bitmap data

    # 	BITMAPINFOHEADER
    fid.write(struct.pack('i',40)) # size of BITMAPINFOHEADER
    fid.write(struct.pack('i',nx)) # biWidth
    fid.write(struct.pack('i',ny)) # biHeight
    fid.write(struct.pack('h',1)) # biPlanes
    fid.write(struct.pack('h',1)) # biBitCount, number of bits per pixel
    fid.write(struct.pack('i',0)) # biCompression, no compression
    fid.write(struct.pack('i',imsize)) # biSizeImage
    fid.write(struct.pack('i',3790)) # biXPelsPerMeter
    fid.write(struct.pack('i',3790)) # biYPelsPerMeter
    fid.write(struct.pack('i',0)) # biClrUsed
    fid.write(struct.pack('i',0)) # BiClrImportant

    # RGBQUAD
    fid.write(struct.pack('B',0))
    fid.write(struct.pack('B',0))
    fid.write(struct.pack('B',0))
    fid.write(struct.pack('B',0))
    fid.write(struct.pack('B',255))
    fid.write(struct.pack('B',255))
    fid.write(struct.pack('B',255))
    fid.write(struct.pack('B',0))

    # DATA
    q = (A.transpose()).flatten()
    for m in range(0,8*imsize,8):
        t = q[m:(m+8)]
        fid.write(struct.pack('B',convbin(t)))
    fid.close()
    return fid.closed

def convbin(q8):
    out = 0
    for m in range(8):
        out += (2**m)*q8[7-m]
    return out

def d2b(n):
    '''convert denary integer n to binary string bStr'''
    bStr = ''
    if n < 0: 
        raise ValueError #"must be a positive integer"
    #if n == 0: return '0'
    qi = 0
    while n > 0:
        bStr = str(n % 2) + bStr
        n = n >> 1
        qi += 1
    while (qi<8):
        bStr = '0' + bStr
        qi += 1
    return bStr

def readPatt(fn):
    fid = open(fn)
    t = fid.read()
    fid.close()
    fln = 0
    # BITMAPFILEHEADER
    q,fln = gettag(fln,'h',t) # 2 bytes set to 'BM' for bitmap file
    q,fln = gettag(fln,'I',t) # 4 bytes specify size of file
    q,fln = gettag(fln,'h',t) # bfReserved1 must be set to 0
    q,fln = gettag(fln,'h',t) # bfReserved2 must be set to 0
    q,fln = gettag(fln,'i',t) # bfOffBits, 4 bytes specify offset from beginning of file to bitmap data

    # 	BITMAPINFOHEADER
    q,fln = gettag(fln,'i',t) # size of BITMAPINFOHEADER
    nx,fln = gettag(fln,'i',t) # biWidth
    ny,fln = gettag(fln,'i',t) # biHeight
    q,fln = gettag(fln,'h',t) # biPlanes
    q,fln = gettag(fln,'h',t) # biBitCount, number of bits per pixel
    q,fln = gettag(fln,'i',t) # biCompression, no compression
    imsize,fln = gettag(fln,'i',t) # biSizeImage
    q,fln = gettag(fln,'i',t) # biXPelsPerMeter
    q,fln = gettag(fln,'i',t) # biYPelsPerMeter
    q,fln = gettag(fln,'i',t) # biClrUsed
    q,fln = gettag(fln,'i',t) # BiClrImportant

    # RGBQUAD
    q,fln = gettag(fln,'B',t)
    q,fln = gettag(fln,'B',t)
    q,fln = gettag(fln,'B',t)
    q,fln = gettag(fln,'B',t)
    q,fln = gettag(fln,'B',t)
    q,fln = gettag(fln,'B',t)
    q,fln = gettag(fln,'B',t)
    q,fln = gettag(fln,'B',t)

    print (nx,ny,imsize)
    img = F.zeroArrF(nx*ny)
    ind = 0
    for p in range(imsize):
        q,fln = gettag(fln,'B',t)
        qb = d2b(q)
        for bi in range(8):
            img[ind]=float(qb[bi])
            ind += 1
    return img.reshape(ny,nx)

def gettag(fln,tag,t):
    w = struct.calcsize(tag)
    q = struct.unpack(tag,t[fln:(fln+w)])
    #print q
    fln += w
    return (q[0],fln)

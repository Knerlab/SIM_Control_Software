# -*- coding: utf-8 -*-
"""
Created on Mon Jul 01 10:04:42 2013

@author: Kayvan Forouhesh
"""

import serial
import time

error_code = {'R':'No Error','E,8':'Value Out of Range','E,4':'Command parse error, ie wrong number of parameters','E,5':'Unknown command','E,21':'Invalid checksum'}

class zstage():
    def __init__(self,portS='COM6'):
        self.ser = serial.Serial()
        self.ser.port=portS
        self.ser.close()
        self.ser.baudrate=9600
        self.ser.parity=serial.PARITY_NONE
        self.ser.stopbits=1
        self.ser.bytesize=8
        if(not self.ser.isOpen()):     
            self.ser.open()
        self.res=0
        res=self.ser.portstr       # check which port was really used
        if res==portS:
            print('Port Connected')
        else:
            print('Port Not Connected')
        time.sleep(0.1)
        print(self.RW("DATE"))

    def RW(self,command):
        self.ser.flushInput()
        command_string = '<%s\r' % command
        self.ser.write(command_string.encode())
        time.sleep(0.1)
        res=self.ser.read(self.ser.inWaiting()).decode()
        n1 = res.find('<')
        n2 = res.find('\r')
        return res[n1+1:n2]

    def __del__(self):
        self.zero()
        self.ser.close()
        if(self.ser.isOpen()):
            self.ser.close()
        print('Port closed')

    def getPosition(self):
        err = self.RW('PZ')
        try:
            pos = float(err)
        except:
            print(error_code[err])
            pos = -1
        return pos
        
    def setPositionq(self,pos):
        err = self.RW("V %s" %pos)
        if not err=='R':
            print(error_code[err])
        return self.getPosition()

    def setPositionf(self,pos):
        err = self.RW("V %s" %pos)
        if not err=='R':
            print(error_code[err])
        return self.getPosition()

    def zero(self):
        err = self.RW("M")
        print(error_code[err])
        return self.getPosition()



#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      bent83
#
# Created:     09/10/2013
# Copyright:   (c) bent83 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------


from ctypes import *


class USMC_Devices(Structure):
    _fields_ = [("NOD", c_ulong), ("Serial",POINTER(POINTER(c_char*16))),("Version",POINTER(POINTER(c_char*16)))]

class USMC_Parameters(Structure):
    _fields_ = [("AccelT", c_float),("DecelT",c_float), ("PTimeout",c_float),
    ("BTimeout1",c_float),("BTimeout2",c_float),("BTimeout3",c_float),("BTimeout4",c_float),
    ("BTimeoutR",c_float),("BTimeoutD",c_float),("MinP",c_float),("BTO1P",c_float),
    ("BTO2P",c_float),("BTO3P",c_float),("BTO4P",c_float),("MaxLoft",c_ushort),("StartPos",c_ulong),
    ("RTDelta",c_ushort),("RTMinError",c_ushort),("MaxTemp",c_float),("SynOutP",c_byte),
    ("LoftPeriod",c_float),("EncMult",c_float),("Reserved",c_byte)]

class USMC_StartParameters(Structure):
    _fields_ = [("SDivisor",c_byte),("DefDir",c_long),("LoftEn",c_long),("SlStart",c_long),
    ("WSyncIN",c_long),("SyncOutR",c_long),("ForceLoft",c_long),("Reserved",c_byte)]

class USMC_Mode(Structure):
    _fields_ = [("PMode",c_long),("PReg",c_long),("ResetD",c_long),("EMReset",c_long),
    ("Tr1T",c_long),("Tr2T",c_long),("RotTrT",c_long),("TrSwap",c_long),("Tr1En",c_long),
    ("Tr2En",c_long),("RotTeEn",c_long),("RotTrOp",c_long),("Butt1T",c_long),("Butt2T",c_long),
    ("ResetRT",c_long),("SyncOutEn",c_long),("SyncOUTR",c_long),("SyncINOp",c_long),
    ("SyncCount",c_ulong),("SyncInvert",c_long),("EncoderEn",c_ulong),("EncoderInv",c_long),
    ("ResBEnc",c_ulong),("ResEnc",c_ulong),("Reserved",c_byte)]

class USMC_State(Structure):
    _fields_= [("CurPos",c_int),("Temp",c_float),("SDivisor",c_byte),("Loft",c_long),
    ("FullPower",c_long),("CW_CCW",c_long),("Power",c_long),("FullSpeed",c_long),
    ("AReset",c_long),("RUN",c_long),("SyncIN",c_long),("SyncOUT",c_long),("RotTr",c_long),
    ("RotTrErr",c_long),("EmReset",c_long),("Trailer1",c_long),("Trailer2",c_long),
    ("Voltage",c_float),("Reserved",c_byte)]

class USMC_EncoderState(Structure):
    _fields_=[("EncoderPos",c_int),("ECurPos",c_int),("Reserved",c_byte)]

class USMC_Info(Structure):
    _fields_ = [("serial",c_char),("dwVersion",c_ulong),("DevName",c_char),("CurPos",c_int),
    ("DestPos",c_int),("Speed",c_float),("ErrState",c_long),("Reserved",c_byte)]

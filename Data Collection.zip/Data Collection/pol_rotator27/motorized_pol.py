#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      bent83
#
# Created:     08/10/2013
# Copyright:   (c) bent83 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import sys
import ctypes
fl = 'C:\\Program FIles (x86)\\MicroSMC\\'
sys.path.append(fl)
from Mot_pol_params import *

byref = ctypes.byref

mot = ctypes.cdll.LoadLibrary('USMCDLL.dll')
#runfile(r'Z:\Mot_pol_params.py', wdir=r'Z:')

def initializeSettings():
    ''' mode '''
    mode = USMC_Mode()
    mode.PMode = 1 # Turn off buttons (1 = buttons disabled)
    mode.PReg = 1 # current reduction regime
    mode.ResetD = 1 # turn power off and make a whole step (True = apply)
    mode.EMReset = 0 # Quick power off
    mode.Tr1T = 0 # limit switch 1 True state
    mode.Tr2T = 0 # limit switch 2 True state
    mode.RotTrT = 0 # Rotary Transducer True state
    mode.TrSwap = 0 # if True, limit switches are to be swapped
    mode.Tr1En = 0 # if True, limit switch 1 enabled
    mode.Tr2En = 0 # if True, limit switch 2 enabled
    mode.RotTeEn = 0 # if True, rotary Transducer Operation enabled
    mode.RotTrOp = 0 # Rotary Transducer Operation Select (stop on error if True)
    mode.Butt1T = 0 # Button 1 True state
    mode.Butt2T = 0 # Button 2 True state
    mode.ResetRT = 0 # Reset Rotary Transducer
    mode.SyncOutEn = 0 # if True output synchornization enabled
    mode.SyncOUTR = 0 # if True output synchronization counter will be reset
    mode.SyncINOp = 0 # Synchronization input mode
    mode.SyncCount = 0 # number of steps after which synchronization output signal occurs
    mode.SyncInvert = 0 # Set this bit to True to invert output synchornization polarity
    mode.EncoderEn = 0 # Enable Encoder on pins (syncin,rottr)
    mode.EncoderInv = 0 # Invert Encoder Counter Direction
    mode.ResBEnc = 0 # Reset Encoder
    mode.ResEnc = 0 # Reset Encoder
    mode.Reserved # not used
    ''' params '''
    params = USMC_Parameters()
    params.AccelT = 980 # acceleration time in ms
    params.DecelT = 980 # deceleration time in ms
    params.PTimeout = 100 # Time (in ms) after which current will be reduced to 60% of normal
    params.BTimeout1 = 1000 # Time (in ms) after which speed of motor rotation will be equal to the one specified in BT01P
    params.BTimeout2 = 1000
    params.BTimeout3 = 1000
    params.BTimeout4 = 1000
    params.BTimeoutR # Time (in ms) after which reset command will be performed
    params.BTimeoutD # This field reserved
    params.MinP # Speed (steps/sec) while performing reset
    params.BTO1P = 2 # Speed after btimeout1
    params.BTO2P = 8
    params.BTO3P = 32
    params.BTO4P = 128
    params.MaxLoft = 1024 # Value in full steps that will be used in backlash operation
    params.StartPos = 1 # Current position saved to FLASH
    params.RTDelta = 600 # Revolution distance -- number of full steps per one full revolution
    params.RTMinError = 2 # number of full steps missed to raise error flag
    params.MaxTemp = 50 # maximum allowed temp
    params.SynOutP = 5 # duration of output synchronization pulse
    params.LoftPeriod = 3 # Speed (steps/sec) of the lst phase of the backlash operation
    params.EncMult = 1.0 # Encoder step multiplier
    params.Reserved = 0 # NA
    ''' start parameters '''
    stparams = USMC_StartParameters()
    stparams.SDivisor = 4 # Step is divided by this factor (1,2,4,8)
    stparams.DefDir = 0 # Direction for backlash operation (relative)
    stparams.LoftEn = 0 # Enable automatic backlash operation (works if slow start/stop mode is off)
    stparams.SlStart = 1 # if True slow start/stop enabled
    stparams.WSyncIN = 0 # if True, controller will wait for input synchronization to start
    stparams.SyncOutR = 0 # If True, output synchronization counter will be reset
    stparams.ForceLoft = 0 # if True and destination position is equal to the current position, backlash will be performed
    return (mode,params,stparams)
    
    

def init():
    devs = USMC_Devices()
    out1 = mot.USMC_Init(byref(devs))
    return (devs,out1)
    
def close():
    out = mot.USMC_Close()
    return out
    
def getState():
    device = 0
    state = USMC_State()
    out = mot.USMC_GetState(device,byref(state))
    return (state,out)
    
def getMode():
    device = 0
    mode = USMC_Mode()
    out = mot.USMC_GetMode(device,byref(mode))
    return (mode,out)
    
def setMode(mode):
    device = 0
    out = mot.USMC_SetMode(device,byref(mode))
    return (mode,out)
    
def getParams():
    device = 0
    params = USMC_Parameters()
    out = mot.USMC_GetParameters(device,byref(params))
    return (params,out)
    
def setParams(params):
    device = 0
    out = mot.USMC_SetParameters(device,byref(params))
    return (params,out)
    
def getStartParams():
    device = 0
    stparams = USMC_StartParameters()
    out = mot.USMC_GetStartParameters(device,byref(stparams))
    return (stparams,out)
    
def Start(pos,stparams):
    device = 0
    speed = ctypes.c_float(100)
    out = mot.USMC_Start(device,pos,byref(speed),byref(stparams))
    return (speed,stparams,out)    

def Stop():
    device = 0
    out = mot.USMC_Stop(device)
    return out
    
    